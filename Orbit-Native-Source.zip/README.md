# Orbit native mobile preview

This project packages Orbit's mobile interface as installed Android and iOS apps using Capacitor 8.6.0. Assets are bundled locally; it does not load the public website as its application shell.

Implemented: catalogue search, season/episode selection, local watchlist, preferences, direct HTTPS video, HLS handling, and the generated colour/sound player test.

**Native torrent playback is not implemented in this preview.** Packaging the existing web player does not add a BitTorrent engine. Do not describe this as working mobile Torrentio playback.

## Build

Use Node.js 22 or later, then `npm ci --ignore-scripts`, `npm run verify-assets`, and `npx cap sync`.

- Android: Java 21, Android SDK 36, then `cd android` and `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`). Debug APKs are for testing, not a signed production release.
- iPhone: macOS and Xcode 26 or later, open `ios/App/App.xcodeproj`. Simulator builds do not need a distribution identity. Installing on a real iPhone and distributing through TestFlight/App Store require Apple signing/provisioning setup.

## Next playback milestone

A native engine must accept a validated source `infoHash`, exact `fileIdx`, and trackers; expose on-demand seekable media; support compatible decoding; report peers/buffering/errors; and clean up per-playback resources. It must not silently pick the largest episode in a season pack when an explicit index exists.

That engine must be implemented and tested independently on both platforms. The desktop Node.js/FFmpeg engine cannot simply be copied into Safari or WKWebView. No payment account, API key, signing identity, or private credential is included here.
