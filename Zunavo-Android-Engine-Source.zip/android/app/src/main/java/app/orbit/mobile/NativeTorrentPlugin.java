package app.orbit.mobile;

import android.content.Intent;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONArray;
import java.util.ArrayList;

@CapacitorPlugin(name="NativeTorrent")
public class NativeTorrentPlugin extends Plugin {
    @PluginMethod public void play(PluginCall call) {
        String hash=call.getString("infoHash", "");
        int fileIdx=call.getInt("fileIdx",-1);
        if(!hash.matches("[a-fA-F0-9]{40}") || fileIdx < -1 || fileIdx > 65535) { call.reject("Invalid torrent source.");return; }
        ArrayList<String> trackers=new ArrayList<>();
        JSONArray sources=call.getArray("sources");
        if(sources!=null) for(int i=0;i<Math.min(sources.length(),32);i++) {
            String tracker=sources.optString(i,"");
            if(tracker.startsWith("tracker:"))tracker=tracker.substring(8);
            if(tracker.length()<2048 && tracker.matches("(?i)^(udp|https?)://[^\\s]+$"))trackers.add(tracker);
        }
        Intent intent=new Intent(getContext(),TorrentPlayerActivity.class);
        intent.putExtra("hash",hash.toLowerCase(java.util.Locale.ROOT));
        intent.putExtra("index",fileIdx);
        intent.putExtra("filename",call.getString("filename",""));
        intent.putExtra("title",call.getString("title","Zunavo"));
        intent.putExtra("key",call.getString("key",hash));
        intent.putStringArrayListExtra("trackers",trackers);
        getActivity().runOnUiThread(()->{ getActivity().startActivity(intent);JSObject result=new JSObject();result.put("opened",true);call.resolve(result); });
    }
}
