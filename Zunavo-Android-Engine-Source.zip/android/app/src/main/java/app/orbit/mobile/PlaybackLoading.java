package app.orbit.mobile;

/** Bounded recovery: a stalled connection must not leave an endless spinner. */
final class PlaybackLoading {
    private int retries;
    boolean retry() { if (retries >= 2) return false; retries++; return true; }
    long retryDelayMs() { return retries * 1500L; }
    static String label(boolean reconnecting, long bufferedMs) {
        String label = reconnecting ? "Reconnecting…" : "Loading video…";
        long seconds = Math.max(0, bufferedMs) / 1000;
        return seconds > 0 ? label + " · " + seconds + (seconds == 1 ? " second ready" : " seconds ready") : label;
    }
}
