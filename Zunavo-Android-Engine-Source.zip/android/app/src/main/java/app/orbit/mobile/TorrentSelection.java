package app.orbit.mobile;

import java.io.File;
import java.io.IOException;
import java.util.Locale;

final class TorrentSelection {
    static boolean video(String name) {
        return name.toLowerCase(Locale.ROOT).matches(".*\\.(mp4|m4v|mkv|webm|avi|mov|ts)$");
    }
    static int select(String[] paths, int requested, String filename) {
        if (requested >= 0) {
            if (requested >= paths.length || !video(paths[requested])) throw new IllegalArgumentException("The selected source does not identify a video file.");
            return requested;
        }
        int chosen = -1;
        for (int i=0;i<paths.length;i++) {
            if (!video(paths[i])) continue;
            if (filename != null && !filename.isEmpty()) {
                if (!paths[i].equals(filename) && !new File(paths[i]).getName().equals(filename)) continue;
            }
            if (chosen >= 0) throw new IllegalArgumentException("This source contains several videos. Choose a source with an exact episode file.");
            chosen=i;
        }
        if (chosen < 0) throw new IllegalArgumentException("No matching video was found in this source.");
        return chosen;
    }
    static File contained(File root, String path) throws IOException {
        File result = new File(root,path).getCanonicalFile();
        if (new File(path).isAbsolute() || !result.getPath().startsWith(root.getCanonicalPath()+File.separator)) throw new IOException("Unsafe source file path.");
        return result;
    }
    static int readSize(long position,long length,long torrentOffset,int pieceLength,int requested) {
        if(position<0 || position>length || pieceLength<=0) throw new IllegalArgumentException("Invalid video position.");
        return (int)Math.min(Math.min((long)requested,length-position),pieceLength-(torrentOffset+position)%pieceLength);
    }
}
