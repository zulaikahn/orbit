package app.orbit.mobile;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.WindowManager;
import android.view.View;
import android.widget.*;
import androidx.media3.common.*;
import androidx.media3.datasource.*;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy;
import androidx.media3.ui.PlayerView;
import org.libtorrent4j.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class TorrentPlayerActivity extends Activity {
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private volatile boolean stopped;
    private SessionManager session;
    private TorrentHandle torrent;
    private TorrentInfo info;
    private File cache,video;
    private long size,offset;
    private ExoPlayer player;
    private final PlaybackLoading recovery = new PlaybackLoading();
    private ProgressBar loading;
    private Button retryButton;
    private boolean waiting = true, reconnecting, failed;
    private boolean fullscreen;
    private final Runnable loadingTick = new Runnable() {
        @Override public void run() {
            if(stopped)return;
            if(waiting && !failed) {
                long buffered = player == null ? 0 : Math.max(0, player.getBufferedPosition()-player.getCurrentPosition());
                message(PlaybackLoading.label(reconnecting, buffered));
            }
            ui.postDelayed(this, 500);
        }
    };
    long testPosition(){return player==null?0:player.getCurrentPosition();}
    void testSeek(long position){if(player!=null)player.seekTo(position);}
    boolean testLoadingVisible(){return loading.getVisibility()==View.VISIBLE;}
    private TextView status; private volatile String lastStatus="Starting"; String testStatus(){return lastStatus;}
    private String progressKey;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setBackgroundColor(0xff0c0f13);
        Button back=new Button(this);back.setText("← Back to Zunavo");back.setOnClickListener(v->finish());layout.addView(back);
        TextView title=new TextView(this);title.setText(getIntent().getStringExtra("title"));title.setTextColor(0xfff7f8fa);title.setPadding(24,16,24,16);layout.addView(title);
        status=new TextView(this);status.setTextColor(0xffb4ef74);status.setPadding(24,16,24,16);layout.addView(status);
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        loading=new ProgressBar(this);loading.setContentDescription("Loading video");layout.addView(loading);
        retryButton=new Button(this);retryButton.setText("Try again");retryButton.setVisibility(View.GONE);
        retryButton.setOnClickListener(v->{startActivity(getIntent());finish();});layout.addView(retryButton);
        PlayerView view=new PlayerView(this);view.setId(android.view.View.generateViewId());layout.addView(view,new LinearLayout.LayoutParams(-1,0,1));setContentView(layout);
        view.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        view.setFullscreenButtonClickListener(expanded->{
            fullscreen=expanded;
            back.setVisibility(expanded?View.GONE:View.VISIBLE);
            title.setVisibility(expanded?View.GONE:View.VISIBLE);
            status.setVisibility(expanded?View.GONE:View.VISIBLE);
            loading.setVisibility(!expanded && waiting?View.VISIBLE:View.GONE);
            if(android.os.Build.VERSION.SDK_INT>=30 && getWindow().getInsetsController()!=null){if(expanded)getWindow().getInsetsController().hide(android.view.WindowInsets.Type.systemBars());else getWindow().getInsetsController().show(android.view.WindowInsets.Type.systemBars());}
        });
        progressKey=getIntent().getStringExtra("key");
        message("Loading video…");ui.post(loadingTick);
        worker.execute(()->prepare(view));
    }
    private void message(String value) { if(value.equals(lastStatus))return;lastStatus=value;ui.post(()->{if(!stopped)status.setText(value);}); }
    private void loadingState(boolean value) { waiting=value;loading.setVisibility(value&&!fullscreen?View.VISIBLE:View.GONE); }
    private void fail(String text) { ui.post(()->{if(stopped)return;failed=true;loadingState(false);message(text);retryButton.setVisibility(View.VISIBLE);}); }
    private void prepare(PlayerView view) {
        try {
            cache=new File(getCacheDir(),"zunavo-torrent-"+UUID.randomUUID());
            if(!cache.mkdirs())throw new IOException("Could not create video cache.");
            session=new SessionManager();session.start();session.startDht();
            String hash=getIntent().getStringExtra("hash");
            StringBuilder magnet=new StringBuilder("magnet:?xt=urn:btih:").append(hash);
            ArrayList<String> trackers=getIntent().getStringArrayListExtra("trackers");
            if(trackers!=null)for(String tracker:trackers)magnet.append("&tr=").append(Uri.encode(tracker));
            byte[] metadata=null;
            for(int attempt=0;attempt<2 && !stopped;attempt++) {
                if(attempt>0){ui.post(()->reconnecting=true);Thread.sleep(1500);}
                metadata=session.fetchMagnet(magnet.toString(),30,cache);
                if(metadata!=null)break;
            }
            if(stopped)return;
            if(metadata==null)throw new IOException("The video did not respond.");
            info=TorrentInfo.bdecode(metadata);
            FileStorage files=info.files();String[] names=new String[files.numFiles()];
            for(int i=0;i<names.length;i++){names[i]=files.filePath(i);TorrentSelection.contained(cache,names[i]);}
            int index=TorrentSelection.select(names,getIntent().getIntExtra("index",-1),getIntent().getStringExtra("filename"));
            size=files.fileSize(index);offset=files.fileOffset(index);video=TorrentSelection.contained(cache,names[index]);
            if(size<=0 || size>Math.max(0,cache.getUsableSpace()-128L*1024*1024))throw new IOException("Not enough free space for this video. Choose a smaller video.");
            Priority[] priorities=Priority.array(Priority.IGNORE,names.length);priorities[index]=Priority.DEFAULT;
            long metadataRemovalDeadline=SystemClock.elapsedRealtime()+10000; while(!stopped && session.find(info.infoHash())!=null && SystemClock.elapsedRealtime()<metadataRemovalDeadline)Thread.sleep(50); if(stopped)return; if(session.find(info.infoHash())!=null)throw new IOException("The previous torrent session did not close. Please retry."); session.download(info,cache,null,priorities,null,TorrentFlags.SEQUENTIAL_DOWNLOAD);
            long until=SystemClock.elapsedRealtime()+15000;
            while(!stopped && (torrent=session.find(info.infoHash()))==null && SystemClock.elapsedRealtime()<until)Thread.sleep(100);
            if(stopped)return;
            if(torrent==null)throw new IOException("Could not start the torrent session.");
            torrent.unsetFlags(TorrentFlags.UPLOAD_MODE.or_(TorrentFlags.STOP_WHEN_READY));torrent.setFlags(TorrentFlags.SEQUENTIAL_DOWNLOAD);if(trackers!=null)for(String tracker:trackers)torrent.addTracker(new AnnounceEntry(tracker));torrent.resume();torrent.forceReannounce();
            ui.post(()->{
                if(stopped)return;
                reconnecting=false;
                player=new ExoPlayer.Builder(this).build();view.setPlayer(player);
                DataSource.Factory factory=()->new PieceSource();
                player.setMediaSource(new ProgressiveMediaSource.Factory(factory).setLoadErrorHandlingPolicy(new DefaultLoadErrorHandlingPolicy(1)).createMediaSource(MediaItem.fromUri("zunavo-torrent://video")));
                long resume=getPreferences(MODE_PRIVATE).getLong(progressKey,0);if(resume>0)player.seekTo(resume);
                player.addListener(new Player.Listener(){
                    @Override public void onPlaybackStateChanged(int state){
                        if(state==Player.STATE_READY){loadingState(false);reconnecting=false;message("Playing");}
                        else if(state==Player.STATE_BUFFERING){loadingState(true);}
                        else if(state==Player.STATE_ENDED){loadingState(false);message("Finished");}
                    }
                    @Override public void onPlayerError(PlaybackException error){
                        android.util.Log.e("ZunavoTorrent","Playback failed",error);
                        boolean formatError=error.errorCode>=3000 && error.errorCode<5000;
                        if(!formatError && recovery.retry()) {
                            reconnecting=true;loadingState(true);message("Reconnecting…");
                            ui.postDelayed(()->{if(stopped||player==null)return;try{torrent.forceReannounce();player.prepare();player.play();}catch(RuntimeException retryError){fail("We couldn’t load this video. Try again or go back to choose another video.");}},recovery.retryDelayMs());
                        } else fail(formatError?"This video format can’t play on this phone. Go back to choose another video.":"We couldn’t load this video. Try again or go back to choose another video.");
                    }
                });
                player.prepare();player.play();
            });
        } catch(Throwable error) { android.util.Log.e("ZunavoTorrent","Preparation failed",error);fail("We couldn’t load this video. Try again or go back to choose another video."); }
    }
    private final class PieceSource extends BaseDataSource {
        private long position,remaining;private RandomAccessFile file;private boolean opened;
        PieceSource(){super(false);}
        @Override public long open(DataSpec spec)throws IOException {
            transferInitializing(spec);position=spec.position;
            if(position<0 || position>size)throw new IOException("Invalid seek position.");
            remaining=spec.length==C.LENGTH_UNSET?size-position:Math.min(spec.length,size-position);
            opened=true;transferStarted(spec);return remaining;
        }
        @Override public Uri getUri(){return Uri.parse("zunavo-torrent://video");}
        @Override public int read(byte[] buffer,int start,int count)throws IOException {
            if(count==0)return 0;if(remaining==0)return C.RESULT_END_OF_INPUT;
            int piece=(int)((offset+position)/info.pieceLength());
            int read=TorrentSelection.readSize(position,size,offset,info.pieceLength(),(int)Math.min(count,remaining));
            long deadline=SystemClock.elapsedRealtime()+30000;
            try {
                torrent.setPieceDeadline(piece,0);
                for(int ahead=1;ahead<=6 && piece+ahead<info.numPieces();ahead++)torrent.setPieceDeadline(piece+ahead,ahead*1000);
                while(!stopped && (!torrent.havePiece(piece)||!video.exists())) {
                    if(SystemClock.elapsedRealtime()>deadline)throw new IOException("Peers stopped sending this part of the video. Try another source.");
                    Thread.sleep(100);
                }
                if(stopped)throw new InterruptedIOException("Player closed.");
                if(file==null)file=new RandomAccessFile(video,"r");
                file.seek(position);file.readFully(buffer,start,read);
                position+=read;remaining-=read;bytesTransferred(read);return read;
            }catch(InterruptedException error){Thread.currentThread().interrupt();throw new InterruptedIOException("Playback interrupted.");}
            catch(RuntimeException error){throw new IOException("Torrent connection stopped.",error);}
        }
        @Override public void close()throws IOException {try{if(file!=null)file.close();}finally{file=null;if(opened){opened=false;transferEnded();}}}
    }
    @Override protected void onStop(){super.onStop();finish();}
    @Override protected void onDestroy(){
        stopped=true;
        ui.removeCallbacksAndMessages(null);
        if(player!=null){long position=player.getCurrentPosition();if(progressKey!=null)getPreferences(MODE_PRIVATE).edit().putLong(progressKey,position).apply();player.release();player=null;}
        worker.execute(()->{try{if(session!=null)session.stop();}finally{if(cache!=null)deleteCache(cache);}});worker.shutdown();
        super.onDestroy();
    }
    private void deleteCache(File path){try{if(!path.getCanonicalPath().startsWith(cache.getCanonicalPath()+File.separator)&&!path.equals(cache)){path.delete();return;}File[] children=path.listFiles();if(children!=null)for(File child:children)deleteCache(child);path.delete();}catch(IOException ignored){}}
}
