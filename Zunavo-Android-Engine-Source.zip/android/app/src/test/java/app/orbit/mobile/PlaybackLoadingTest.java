package app.orbit.mobile;
import org.junit.Test;
import static org.junit.Assert.*;

public class PlaybackLoadingTest {
    @Test public void recoveryStopsAfterTwoRetries() {
        PlaybackLoading loading=new PlaybackLoading();
        assertTrue(loading.retry());assertEquals(1500,loading.retryDelayMs());
        assertTrue(loading.retry());assertEquals(3000,loading.retryDelayMs());
        assertFalse(loading.retry());assertFalse(loading.retry());
    }
    @Test public void showsOnlyMeasuredBufferProgress() {
        assertEquals("Loading video…",PlaybackLoading.label(false,0));
        assertEquals("Loading video…",PlaybackLoading.label(false,-500));
        assertEquals("Loading video… · 3 seconds ready",PlaybackLoading.label(false,3500));
        assertEquals("Reconnecting… · 1 second ready",PlaybackLoading.label(true,1000));
    }
}
