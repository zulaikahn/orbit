package app.orbit.mobile;
import org.junit.Test;
import static org.junit.Assert.*;
import java.io.File;
import java.io.IOException;
public class TorrentSelectionTest {
    @Test public void explicitEpisodeWins(){assertEquals(1,TorrentSelection.select(new String[]{"episode1.mkv","episode2.mkv"},1,""));}
    @Test(expected=IllegalArgumentException.class) public void ambiguousSeasonNeverPlaysWrongEpisode(){TorrentSelection.select(new String[]{"episode1.mkv","episode2.mkv"},-1,"");}
    @Test public void filenameFindsEpisode(){assertEquals(1,TorrentSelection.select(new String[]{"season/one.mp4","season/two.mp4"},-1,"two.mp4"));}
    @Test(expected=IOException.class) public void parentPathCannotEscapeCache()throws Exception{TorrentSelection.contained(new File("cache"),"../../outside");}
    @Test public void readsStopAtTorrentPieceBoundary(){assertEquals(12,TorrentSelection.readSize(10,1000,10,32,100));assertEquals(5,TorrentSelection.readSize(995,1000,0,32,100));}
}
