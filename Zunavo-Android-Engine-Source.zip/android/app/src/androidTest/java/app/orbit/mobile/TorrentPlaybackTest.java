package app.orbit.mobile;
import android.content.Intent;
import androidx.test.core.app.ActivityScenario;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicLong;
import static org.junit.Assert.*;

public class TorrentPlaybackTest {
  @Test public void nativeTorrentPlaysAndSeeks() throws Exception {
    String hash=InstrumentationRegistry.getArguments().getString("hash");
    assertNotNull("Fixture hash missing",hash);
    Intent intent=new Intent(InstrumentationRegistry.getInstrumentation().getTargetContext(),TorrentPlayerActivity.class);
    intent.putExtra("hash",hash);intent.putExtra("index",0);intent.putExtra("title","Zunavo generated video test");intent.putExtra("key","test:"+System.nanoTime());
    ArrayList<String> trackers=new ArrayList<>();trackers.add("http://10.0.2.2:49002/announce");intent.putStringArrayListExtra("trackers",trackers);
    try(ActivityScenario<TorrentPlayerActivity> scenario=ActivityScenario.launch(intent)) {
      scenario.onActivity(a->{assertEquals("Loading video…",a.testStatus());assertTrue(a.testLoadingVisible());});
      java.util.concurrent.atomic.AtomicReference<String> status=new java.util.concurrent.atomic.AtomicReference<>("Starting"); AtomicLong position=new AtomicLong();long until=System.currentTimeMillis()+120000;
      while(position.get()<8000 && System.currentTimeMillis()<until){scenario.onActivity(a->{position.set(a.testPosition());status.set(a.testStatus());});Thread.sleep(300);}
      assertTrue("Native torrent never reached playback: "+status.get(),position.get()>=8000);
      scenario.onActivity(a->{assertEquals("Playing",a.testStatus());assertFalse(a.testLoadingVisible());});
      scenario.onActivity(a->a.testSeek(12000));until=System.currentTimeMillis()+30000;
      while(position.get()<20000 && System.currentTimeMillis()<until){scenario.onActivity(a->{position.set(a.testPosition());status.set(a.testStatus());});Thread.sleep(300);}
      assertTrue("Seek did not resume playback",position.get()>=20000);
    }
  }
}
