const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const html=fs.readFileSync(require('node:path').join(__dirname,'../www/index.html'),'utf8'); const source=html.split('// BEGIN ZUNAVO LOADING')[1].split('// END ZUNAVO LOADING')[0];
function harness(){
  let now=0,id=0,calls=0,video,status;const nodes=[],timeouts=new Map(),intervals=new Map();
  class Element extends EventTarget{constructor(){super();this.children=[];this.hidden=false;this.textContent='';}append(...children){this.children.push(...children);}setAttribute(){}insertAdjacentElement(_,node){nodes.push(node);}}
  class Video extends Element{constructor(){super();this.currentTime=0;this.duration=100;this.isConnected=true;this.paused=false;this.end=0;this.buffered={length:1,start:()=>0,end:()=>this.end};}play(){return Promise.resolve();}}
  const dialog=new Element();dialog.open=true;
  const document={head:new Element(),createElement:()=>new Element(),querySelector:s=>s==='#orbitPlayer'?video:status};
  const context={document,dialog,AbortController,Date:{now:()=>now},MutationObserver:class{observe(){}disconnect(){}},playSource(){calls++;if(video)video.isConnected=false;video=new Video();status=new Element();},setTimeout(fn,delay){timeouts.set(++id,{fn,due:now+delay});return id;},clearTimeout:id=>timeouts.delete(id),setInterval(fn){intervals.set(++id,fn);return id;},clearInterval:id=>intervals.delete(id)};
  vm.createContext(context);vm.runInContext(source,context);
  return {start(){context.playSource('Video','https://example.com/video.mp4','series:test');},get video(){return video;},get panel(){return nodes.at(-1);},get calls(){return calls;},advance(ms){now+=ms;for(const fn of [...intervals.values()])fn();for(const [id,t]of [...timeouts])if(t.due<=now){timeouts.delete(id);t.fn();}},close(){dialog.open=false;dialog.dispatchEvent(new Event('close'));},event(name){video.dispatchEvent(new Event(name));}};
}
test('loading reports real buffer and disappears when playing',()=>{const h=harness();h.start();assert.equal(h.panel.children[1].textContent,'Loading video…');h.video.end=8;h.advance(500);assert.match(h.panel.children[1].textContent,/8 seconds ready/);h.event('playing');assert.equal(h.panel.children[0].hidden,true);assert.equal(h.panel.children[1].textContent,'Playing');});
test('connection stalls retry twice then provide a manual retry',()=>{const h=harness();h.start();for(let i=0;i<2;i++){h.advance(26000);assert.equal(h.panel.children[1].textContent,'Reconnecting…');h.advance(3000);}assert.equal(h.calls,3);h.advance(26000);assert.equal(h.panel.children[2].hidden,false);h.advance(60000);assert.equal(h.calls,3);h.panel.children[2].onclick();assert.equal(h.calls,4);});
test('closing cancels a pending reconnection',()=>{const h=harness();h.start();h.event('error');h.close();h.advance(10000);assert.equal(h.calls,1);});
test('unsupported format stops without repeated requests',()=>{const h=harness();h.start();h.video.error={code:4};h.event('error');h.advance(60000);assert.equal(h.calls,1);assert.match(h.panel.children[1].textContent,/format/);assert.equal(h.panel.children[2].hidden,false);});
test('user pause does not reconnect',()=>{const h=harness();h.start();h.event('playing');h.event('pause');h.advance(60000);assert.equal(h.calls,1);assert.equal(h.panel.children[1].textContent,'Paused');});
