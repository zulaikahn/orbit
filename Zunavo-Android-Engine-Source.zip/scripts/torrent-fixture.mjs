// Only an original, generated test video is shared by this local test seeder.
import WebTorrent from 'webtorrent';
import http from 'node:http';
import fs from 'node:fs';
const client=new WebTorrent({dht:false,tracker:false,lsd:false,utp:false,natUpnp:false,natPmp:false,torrentPort:49001});
client.on('error',error=>{console.error(error.message);process.exit(1)});
client.seed(process.argv[2],{announce:[],private:true},torrent=>{
  const peer=Buffer.from([10,0,2,2,49001>>8,49001&255]);
  const body=Buffer.concat([Buffer.from('d8:completei1e10:incompletei0e8:intervali2e5:peers6:'),peer,Buffer.from('e')]);
  http.createServer((req,res)=>{if(!req.url.startsWith('/announce')){res.writeHead(404);res.end();return;}res.writeHead(200,{'Content-Type':'text/plain'});res.end(body);}).listen(49002,'0.0.0.0',()=>fs.writeFileSync('fixture-hash.txt',torrent.infoHash));
});
