// Native-only adapter. The public website and iPhone retain their existing player.
(() => {
  const bridge=window.Capacitor;
  if(bridge?.getPlatform?.()!=='android'||!bridge.isPluginAvailable('NativeTorrent'))return;
  const nativePlayer=bridge.registerPlugin('NativeTorrent');
  const previousKind=sourceKind;
  sourceKind=function(source){return /^[a-f0-9]{40}$/i.test(source.infoHash||'')?'torrent':previousKind(source)};
  window.playTorrent=async function(title,source,key){
    const index=source.fileIdx==null?-1:Number(source.fileIdx);
    if(!Number.isInteger(index)||index< -1||index>65535){alert('This source has an invalid episode file index.');return;}
    try{
      await nativePlayer.play({title,key,infoHash:source.infoHash,fileIdx:index,filename:source.behaviorHints?.filename||'',sources:Array.isArray(source.sources)?source.sources:[]});
    }catch(error){alert(error.message||'The Android player could not open. Try another source.');}
  };
  const existingSettings=openOrbitSettings;
  openOrbitSettings=function(){existingSettings();const group=[...document.querySelectorAll('.settings-group')].at(-1);if(group)group.innerHTML='<h3>About Zunavo Android</h3><p>Experimental native torrent player 0.2.1. Torrent playback uses peers and temporary phone storage. Leaving the player stops playback. Video and audio support depends on the phone. Use sources you have permission to access.</p>';};
  for(const note of document.querySelectorAll('p'))if(note.textContent==='Native torrent playback is not implemented in this preview.')note.textContent='Experimental native Android torrent playback is enabled. Physical-phone testing is still required.';
})();
