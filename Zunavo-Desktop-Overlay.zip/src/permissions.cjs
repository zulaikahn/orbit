function allowPlayerFullscreen(permission,requestingUrl,origin,ownContents){
  if(permission!=='fullscreen'||!ownContents)return false;
  try{return new URL(requestingUrl).origin===origin}catch{return false}
}
module.exports={allowPlayerFullscreen};
