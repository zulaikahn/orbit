const fs=require('fs/promises'),path=require('path');const {selectFile,magnetFor}=require('./media.cjs');
class PlaybackEngine{
  constructor(client,cachePath){this.client=client;this.cachePath=cachePath;this.pending=new Map();this.failures=new Map();this.closed=false;client.on('error',()=>{})}
  static async create(cachePath){await fs.mkdir(cachePath,{recursive:true});const {default:WebTorrent}=await import('webtorrent');return new PlaybackEngine(new WebTorrent({maxConns:40,natUpnp:false,natPmp:false}),cachePath)}
  async torrent(hash,trackers=[]){if(this.closed)throw Error('Zunavo playback is closed.');const id=hash.toLowerCase();magnetFor(id,trackers);if(this.pending.has(id))return this.pending.get(id);if(this.pending.size>=4)throw Error('Close a playing source before opening another.');this.failures.delete(id);const pending=new Promise((resolve,reject)=>{let torrent;const fail=error=>{this.failures.set(id,error.message);clearTimeout(timer);if(torrent&&!torrent.destroyed)torrent.destroy();reject(error)};const timer=setTimeout(()=>fail(Error('No peers provided the source metadata. Try another source.')),90000);try{torrent=this.client.add(magnetFor(id,trackers),{path:this.cachePath,deselect:true,addUID:true,destroyStoreOnDestroy:true},t=>{clearTimeout(timer);this.failures.delete(id);t.removeListener('error',fail);t.on('error',()=>{});resolve(t)});torrent.once('error',fail)}catch(e){fail(e)}});this.pending.set(id,pending);pending.catch(()=>{if(this.pending.get(id)===pending)this.pending.delete(id)});return pending}
  async file(hash,index,trackers,filename){const torrent=await this.torrent(hash,trackers);return selectFile(torrent.files,index,filename)}
  state(hash){const t=this.client.torrents?.find(t=>t.infoHash===hash);return {peers:t?.numPeers||0,downloaded:t?.downloaded||0,speed:t?.downloadSpeed||0,metadata:!!t?.ready,message:this.failures.get(hash)||''}}
  async close(){this.closed=true;await new Promise(resolve=>this.client.destroy(resolve));this.pending.clear()}
}
module.exports={PlaybackEngine};



